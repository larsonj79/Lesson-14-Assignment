# load in the package
library(gradeR)

calcGradesForGradescope("Lesson_14_Assignment_Logistic_Regression.R",   # each student's submission must be named this!
                        "Lesson_14_Assignment_Tests.R") # the file with all of the testthat tests 
  
